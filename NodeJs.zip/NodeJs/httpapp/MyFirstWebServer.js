'use strict'


const http=require('http');


const server=http.createServer((req,res)=> {

res.statusCode=200;
res.setHeader('Content-Type','application/json');
var data={message:'Hello I am node server'}
res.end(JSON.stringify(data));


});


//start the server
var port=3000
var hostname='localhost'

server.listen(port,hostname,()=>
{

console.log(`Http running at ${hostname} : ${port}`)

});
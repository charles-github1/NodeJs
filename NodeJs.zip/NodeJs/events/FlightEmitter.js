
'use strict'

const EventEmitter=require('events');


var FlightEmitter=new EventEmitter();

 //Declare flight Object

 var Flight =function(){

    this.data = {
    number: null,
    origin: null,
    destination: null,
    departs: null,
    arrives: null,
    actualDepart: null,
    actualArrive: null
  };

var self = this;

 //Events
FlightEmitter.on('schdule',function(){
	 //
	console.log('---------- Flight Detetails--------');
	console.log(self.getInformation().number + " -- " +
		       self.getInformation().origin + "  -- " + 
		       self.getInformation().destination
		       );
	   setTimeout(function(){
      		self.announce();
        },10000);
 
});

FlightEmitter.on('announce',function(flight){
		console.log(flight.data.number + ' announced ');
		  setTimeout(function(){
				self.startCheckin();
        },10000);
});

FlightEmitter.on('checkin',function(flight){
		console.log(flight.data.number + ' checkin...');
	    setTimeout(function(){
	   		self.startBoarding();
        },10000);

});

FlightEmitter.on('bording',function(flight){
		console.log(flight.data.number + ' bording...');
	   setTimeout(function(){
	   		self.startOnBoarding();
        },10000);

});

 //Flight Apis

  this.schdule=function(flight){

   //Fill the data.
    for(var prop in this.data) {
      if(this.data[prop] !== 'undefined') {
        this.data[prop] = flight[prop];
      }
    }
    FlightEmitter.emit('schdule');

  };

  this.announce=function(){
  		FlightEmitter.emit('announce',this);
  };

  this.startCheckin=function(){
  		FlightEmitter.emit('checkin',this);
  };
  this.closeGate=function(){
  	FlightEmitter.emit('closegate',this);

  };
  this.startBoarding=function(){
  		 FlightEmitter.emit('bording',this);

  };
  this.startOnBoarding=function(){
  		 FlightEmitter.emit('onbording',this);

  };
  this.triggerDepart=function(){

  }

  this.getInformation=function(){
  	return this.data;
  }

 }
 //export Filght
module.exports = Flight;
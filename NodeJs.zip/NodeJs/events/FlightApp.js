'use strict'

var Flight=require('./FlightEmitter.js');


var jetAirways=new Flight();


var data={

    number:234,
    origin:'Chennai',
    destination:'Srilanka',
    departs:'Tonight 9 pm',
    arrives:'Tommorrw morning 9 pm',
    actualDepart:new Date(),
    actualArrive:new Date()+1

}
//console.dir(jetAirways);

jetAirways.schdule(data);
var fs = require('fs');

//Reader Stream
var stream = fs.createReadStream('dumpfile.txt');
//Writer Stream
var ostream = fs.createWriteStream('dumpfile2.txt');

stream.on('data', function (chunk) {

    console.log('----------------begin chunk----------------');
    console.log(chunk.toString());
    console.log('----------------end chunk----------------');
    ostream.write(chunk.toString());

});


stream.on('end', function () {
    console.log('----------------reached file end----------------');
});
'use strict'

const EventEmitter=require('events');

class MyEmitter extends EventEmitter{



}


const myEmitter=new MyEmitter();

myEmitter.on('click',()=>{

console.log('An click event occured');
});

myEmitter.on('DoubleClick',()=>{

console.log('An Double click event occured');
});


myEmitter.emit('click');

myEmitter.emit('DoubleClick');
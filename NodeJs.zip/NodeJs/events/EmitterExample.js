'use strict'


var EventEmitter=require('events')


class Human extends EventEmitter{

goToBed()
{

    this.emit('sleep');
}


}

var Charles=new Human();

Charles.on('read',()=>{

console.log('Reading Books');

});

Charles.on('sleep',()=>{

console.log('Charles go to sleep ,Switch off the lights');

});

Charles.goToBed();







var Jones=new Human();

Jones.on('read',()=>{

console.log('Reading Books');

});

Jones.on('sleep',()=>{

console.log('Jones go to sleep ,Switch off the lights');

});

Jones.goToBed();
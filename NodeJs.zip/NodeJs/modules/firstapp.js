var rq=require('./hellomodule');

console.dir(rq);
var Customerobj=require('./Customer.js');


var customerlist=Customerobj.findAll();


//console.dir(customerlist);

console.log('-----Original List--------');
//printing customer list


customerlist.forEach(function(customer)
{

console.log(customer.firstName+' '+customer.lastName);

});


/////////////////////////find By Id ///////////////////////////////////////

console.log('-----find by Id =10--------');
Customerobj.findById(10);



////////////////////////save a cusotmer//////////////////////////////////

var tempcust={
                id: 12, firstName: 'Amit', lastName: 'Singh', address: '459 S. International Dr.', city: 'Medavakkam'
            };


console.log('-----Save Temp Cust -------');

Customerobj.save(tempcust);



//printing again

customerlist.forEach(function(customer)
{


console.log(customer.firstName+' '+customer.lastName);

});

///////////////////////////update Customer/////////////////////////

var updtcust={
                id: 12, firstName: 'Amit', lastName: 'Kumar', address: '459 S. International Dr.', city: 'Medavakkam'
            };

console.log('-----update  Cust -------');

Customerobj.update(updtcust);


//printing again

customerlist.forEach(function(customer)
{

console.log(customer.firstName+' '+customer.lastName);

});


/////////////////////////Delete by Id/////////////////////////////


console.log('-----Delete Customer by Id -------');

Customerobj.delete(10);


//printing again

customerlist.forEach(function(customer)
{

console.log(customer.firstName+' '+customer.lastName);

});
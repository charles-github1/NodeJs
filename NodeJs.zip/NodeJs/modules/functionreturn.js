'use strict';

const message='Hai';
let hello='Hello';


exports.sayHi=function()
{

    console.log(`${message}`);
}

exports.sayHello=function()
{

    console.log(`${hello}`)
}

exports.message='from request class';
exports.getCustomers=function()
{

return {

    id:'1',name:'charles',city:'charles'
}

}

exports.getOrders=function()
{

var Order=function()
{
    this.id='A-000'
    this.name='new Order'
    this.date=new Date()
}

return new Order();
}
'use strict';

var name='charles';

console.log('Hey I am first module');
var Customer=require('./customerobj');


console.log(`customer id is ${Customer.getCustomers().id}`);
console.log(`customer name is ${Customer.getCustomers().name}`);

///

console.dir(Customer);

console.log(`cusotmer order id is ${Customer.getOrders().id} and date is ${Customer.getOrders().date}`);
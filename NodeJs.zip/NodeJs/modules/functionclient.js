var welcome=require('./functionreturn.js');

console.dir(welcome);


welcome.sayHi();
welcome.sayHello();

console.log(`value is ${welcome.message}`);
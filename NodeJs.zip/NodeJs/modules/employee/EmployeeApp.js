var employee=require('./Employee');



console.log(`Employee Id is ${employee.id} , city is ${employee.address}`);

console.log(`Salary is ${employee.calculateSalary()}`);
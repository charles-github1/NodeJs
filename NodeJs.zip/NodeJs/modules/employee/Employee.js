
'use strict'


const salary=1000;

let workingdays=5

/*
var Employee={
id:100,name:'Charles',address:'Medavakkam',calculateSalary:function()
{
    return salary*workingdays
    
}
};

module.exports=Employee;

function Employee(){

this.id=200,
this.name='AMit'
this.address='Porur'
this.calculateSalary=function()
{
     return salary*workingdays
}



}

module.exports=new Employee();


var Employee=function (){

this.id=200,
this.name='AMit'
this.address='Poonamalle'
this.calculateSalary=function()
{
     return salary*workingdays
}



}

module.exports=new Employee();


*/

//ES 6 Pattern

class Employee
{
    constructor()
    {
        this.id=100
        this.name='charles'
        this.address='Chennai'
    }


    calculateSalary()
    {

        return salary*workingdays;

    }

}






module.exports=new Employee();



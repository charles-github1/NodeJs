'use strict';


let name='charles';

function sayGreet()
{
    console.log('Greetings');
    return `Hi ${name} , How are you`;
}

console.log(sayGreet());
'use strict';
//object creation
//1.constructor pattern

function Employee()
{
    this.id=100;
    this.name='Charles';
    this.address='Chennai';
    this.calcuateSalary=function()
    {
        return 100.00;
    }


}


function client()
{

var emp=new Employee();

console.log(emp.id);
console.log(emp.name);
console.log(emp.address);
console.log(emp.calcuateSalary());


}

client();
//Literal Pattern

const Customer={
id:100,name:'charles',address:{ street:'Pillayar koil',city:'Medavakkam'},
calcuateSalary:function()
{
    return 1000.00
}

};



customerClient();

function customerClient()
{


console.log(Customer.id);
console.log(Customer.name);
console.log(Customer.address.city);
console.log(Customer.address.street);
console.log(Customer.calcuateSalary());

}

//javascript code
'use strict';

let greetings='welcome';
const greeting1='Hai Iam node';

var name='charles';

console.log(`Hi ${name} is Greeting you `);
console.log('Message is'+greetings);
console.log('Message is',greetings,greeting1);
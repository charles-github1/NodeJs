var express = require('express');

//npm install bodyParser --save
var bodyParser=require('body-Parser');

//Step 2 call function
//Returns expres Object
var app = express();

//Attach Body parser in your application

app.use(bodyParser.json());




  //Data -------- Model
	//send jsonresponse
  var customers = [ {
		id : 1,
		firstName : 'Lee',
		lastName : 'Carroll',
		address : '1234 Anywhere St.',
		city : 'Phoenix',
		orders : [ {
			product : 'Basket',
			price : 29.99,
			quantity : 1,
			orderTotal : 29.99
		}, {
			product : 'Yarn',
			price : 9.99,
			quantity : 1,
			orderTotal : 39.96
		}, {
			product : 'Needes',
			price : 5.99,
			quantity : 1,
			orderTotal : 5.99
		} ]
	}, {
		id : 2,
		firstName : 'Jesse',
		lastName : 'Hawkins',
		address : '89 W. Center St.',
		city : 'Atlanta',
		orders : [ {
			'product' : 'Table',
			price : 329.99,
			quantity : 1,
			orderTotal : 329.99
		}, {
			product : 'Chair',
			price : 129.99,
			quantity : 4,
			orderTotal : 519.96
		}, {
			product : 'Lamp',
			price : 89.99,
			quantity : 5,
			orderTotal : 449.95
		}, ]
	} ];



//Map with HTTP verbs
app.get('/api/customers',function(request,response){
 response.set('Content-Type', 'application/json');
 response.header('Access-Control-Allow-Origin', "*")
   var customerjson;
 try {
     //customerjson= JSON.parse('not json');
	  customerjson = JSON.stringify(customers)
    } catch (er) {
      // uh oh!  bad json!
      response.statusCode = 400;
      return response.end('error:'+er.message);
    }

   response.send(customerjson);

 });

//POST
app.post('/api/customer',function(request,response){
  console.log('POST is called');
  var data = request.body;
  console.log(data);
  console.log(typeof data);
  var result =save(data)
  console.log('After Saving');
  console.log(result);
  response.end('saved...');
});

app.get('/api/customers/:customerId',function(request,response){
	var customerId=parseInt(request.params.customerId);
	console.log(customerId);
	response.end();
});

//PUT
app.put('/api/customers/:customerId',function(request,response){
 console.log('PUT is called');
  response.end();
});

//delete
app.delete('/api/customers/:customerId',function(request,response){
 console.log('DELETE is called');
  response.end();
});

//Service API
var save=function(data){
  customers.push(data);
  return JSON.stringify(customers);
};



var getCustomerById=function(id){
  

customers.forEach(function(customer){

if(customer.id==id)
{
    console.log(`Id : ${customer.id} , firstName :${customer.firstName} , LastName ${customer.lastName}`);
    return customer;
}

})
};
var updateCustomer=function(customerId){


customers.forEach(function(element){

if(customer.id==element.id)
{
    element.firstName=customer.firstName;
    element.lastName=customer.lastName;
    element.city=customer.city;
    element.address=customer.address;
    element.orders=customer.orders;


    return customer;
}

})
	
};

var deleteCustomer=function(id){



var cusind=0;
var index

customers.forEach(function(customer){

if(customer.id==id)
{
  console.log(`Deleting Customer Id : ${customer.id} , firstName :${customer.firstName} , LastName ${customer.lastName}`);   
index=cusind;
   
}else{
cusind=cusind+1
}


})

customers.splice(index,1);



};



//start server
app.listen(3000,function(){
console.log('Web Server is ready!');
});